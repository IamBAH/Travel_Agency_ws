package travel.management.web.resource;

import java.net.URI;
import java.util.List;


import javax.ws.rs.*;
import javax.ws.rs.core.*;

import travel.management.web.data.*;
import travel.management.web.service.*;

/**
 * This class represents a implementation of JAX-RS (JAVA API for RESTful Web Service). 
 * 
 * @author MIAN Farooq and BAH Alpha Oumar
 */

@Path("/travels")
public class TravelResource {
	
	TravelService travelService = new TravelService();
	
	@Context
	UriInfo uriInfo;
	
	/**
	  * Add destination .
	  * 
	  * @param dest
	  * @author MIAN Farooq and BAH Alpha Oumar
	  */
	
	@POST
	@Consumes(MediaType.APPLICATION_XML)
	@Produces(MediaType.APPLICATION_XML)
	public Response  addDestination(Destination dest)  {
	    Destination destination = travelService.addDestination(dest);
	    if(destination == null) {
	      return Response.status(Response.Status.BAD_REQUEST).build();
	    }
	    URI uri = uriInfo.getRequestUri();
	    String newUri = uri.getPath() + "/" + destination.getId_destination();
	    return Response.status(Response.Status.CREATED)
	                   .contentLocation(uri.resolve(newUri))
	                   .build();
}
	 
	/**
	 * Review a list of all countries. 
	 * 
	 * @author MIAN Farooq and BAH Alpha Oumar
	 */
	
	 @Path("/countries")
	 @GET
	 @Produces(MediaType.APPLICATION_XML)
	 public Response getCountries() { 
	    GenericEntity<List<Country>> entities = new GenericEntity<List<Country>>(travelService.getCountry()){};
    
    	return Response.status(Response.Status.OK)
            .entity(entities)
            .build();
	 }
	 
	 /**
	  * Review all destinations by city.
	  *  
	  * @param	id
	  * @author MIAN Farooq and BAH Alpha Oumar
	  */

	 @Path("city/{id}")
	 @GET
	 @Produces(MediaType.APPLICATION_XML)
	 public Response  getDestinationsByCity(@PathParam("id") int id){
		 List<Destination> cityDests = travelService.getDestinationsByCity(id);
		 GenericEntity<List<Destination>> entities = new GenericEntity<List<Destination>>(cityDests) {};
	      
		 return Response.status(Response.Status.OK)
	    		  .entity(entities)
	    		  .build();
	 }
	 
	 /**
	  * Review all cities.
	  *  
	  * @author MIAN Farooq and BAH Alpha Oumar
	  */
	 
	 @Path("/cities")
	 @GET
	 @Produces(MediaType.APPLICATION_XML)
	 public Response  getCities(){
		 List<City> cities = travelService.getCities();
		//needs empty body to preserve generic type
		 GenericEntity<List<City>> entities = new GenericEntity<List<City>>(cities){};
		 
		 return Response.status(Response.Status.OK)
	    		  .entity(entities)
	    		  .build();
	 }
	 
	 /**
	  * Review all destinations types.
	  *  
	  * @author MIAN Farooq and BAH Alpha Oumar
	  */

	 @Path("/typesDests")
	 @GET
	 @Produces(MediaType.APPLICATION_XML)
	 public Response  getDestTypes(){
		 List<Destination_type> destTypes = travelService.getDestinations();
		 GenericEntity<List<Destination_type>> entities = new GenericEntity<List<Destination_type>>(destTypes){};
		 
		 return Response.status(Response.Status.OK)
	    		  .entity(entities)
	    		  .build();
	 }
	 
	 
	 @Path("/destGroups")
	 @GET
	 @Produces(MediaType.APPLICATION_XML)
	 public Response  getDestGroup(){
		 List<Destination_assemble> Destination_assemble = travelService.getDestination_assemble();
		 GenericEntity<List<Destination_assemble>> entities = new GenericEntity<List<Destination_assemble>>(Destination_assemble){};
		 
		 return Response.status(Response.Status.OK)
	    		  .entity(entities)
	    		  .build();
	 }
	 
	 /**
	  * Review destinations by destinations type.
	  * 
	  * @param typeDest
	  * @author MIAN Farooq and BAH Alpha Oumar
	  */
	 
	 @Path("destinations/{id_typeDest}")
	 @GET
	 @Produces(MediaType.APPLICATION_XML)
	 public Response  getDestByTypeDest(@PathParam("id_typeDest") int id_typeDest){
		 List<Destination_each_type_dest> destinations = travelService.getDestination_each_type_dest(id_typeDest);
		 GenericEntity<List<Destination_each_type_dest>> entities = new GenericEntity<List<Destination_each_type_dest>>(destinations){};
	      
	      return Response.status(Response.Status.OK)
	    		  .entity(entities)
	    		  .build();
	 }
	 
	 
	 @GET
	 @Produces(MediaType.APPLICATION_XML)
	 public Response  getAllDest(){
		 List<Destination_each_type_dest> destinations = travelService.getAllDestinations();
		 GenericEntity<List<Destination_each_type_dest>> entities = new GenericEntity<List<Destination_each_type_dest>>(destinations){};
	      
	      return Response.status(Response.Status.OK)
	    		  .entity(entities)
	    		  .build();
	 }
	 
	 /**
	  * Review destinations by id.
	  * 
	  * @param id
	  * @author MIAN Farooq and BAH Alpha Oumar
	  */
	 
	 @GET
	 @Path("/{id}")
	 @Produces(MediaType.APPLICATION_XML)
	 public Response getDestination(@PathParam("id") int id) {
		 Destination_each_type_dest dest = travelService.getDestinationById(id);
		if(dest == null) {
		  return Response.status(Response.Status.NOT_FOUND).build();
		}
		Link link = Link.fromUri(uriInfo.getRequestUri())
		                .rel("self")
		                .type("application/xml")
		                    .build();
		    return Response.status(Response.Status.OK)
		                   .entity(dest)
		                   .links(link)
		                   .build();
	  }
	 
	 /**
	  * Remove destination .
	  * 
	  * @param id
	  * @author MIAN Farooq and BAH Alpha Oumar
	  */
	 
	 @DELETE
	 @Path("/{id}")
	 @Produces(MediaType.APPLICATION_XML)
	 public Response deleteDest(@PathParam("id") int id) { 
	    if(travelService.deleteDestination(id) == false) {
	      return Response.status(Response.Status.NOT_FOUND).build();
	    }
	    return Response.status(Response.Status.OK).build();
	  }
	 
	 /**
	  * Update destination .
	  * 
	  * @param id,dest
	  * @author MIAN Farooq and BAH Alpha Oumar
	  */
	 
	 @PUT
	 @Path("/{id}")
	 @Consumes(MediaType.APPLICATION_XML)
	 @Produces(MediaType.APPLICATION_XML)
	 public Response updateDestination(@PathParam("id") int id, Destination dest) {
	    Destination destination = travelService.updateDestination(id,dest);
	    if(destination == null) {
	      return Response.status(Response.Status.BAD_REQUEST).build();
	    }
	    Link link = Link.fromUri(uriInfo.getRequestUri())
	                    .rel("self")
	                    .type("application/xml")
	                    .build();
	    return Response.status(Response.Status.OK)
	                   .links(link)
	                   .build();
	  }
	
}